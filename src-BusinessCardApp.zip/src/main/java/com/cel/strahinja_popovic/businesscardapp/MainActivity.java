package com.cel.strahinja_popovic.businesscardapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

/**
 * Student name: Strahinja Popovic
 * University of Canberra Student ID: u3165021
 * Subject: Mobile Technologies
 * Purpose: Business Card App Scanner
 */

public class MainActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();

        if(id == R.id.menu_item_last)
        {
            Intent intent = new Intent(MainActivity.this, DisplayListActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
    public void displayListActivity(View view)
    {
        Intent intent = new Intent(MainActivity.this, DisplayListActivity.class);
        startActivity(intent);
    }
}
