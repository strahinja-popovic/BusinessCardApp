package com.cel.strahinja_popovic.businesscardapp;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

/**
 * Student name: Strahinja Popovic
 * University of Canberra Student ID: u3165021
 * Subject: Mobile Technologies
 * Purpose: Business Card App Scanner
 */

public class BusinessCardDataAdapter extends ArrayAdapter<BusinessCardData>
{
    ArrayList<BusinessCardData> arrayData;

    public BusinessCardDataAdapter(Context context, int resource, ArrayList<BusinessCardData> objects)
    {
        super(context, resource, objects);
        arrayData = objects;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        if (convertView == null)
        {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_view_layout, parent, false);
        }
        BusinessCardData bcData = arrayData.get(position);

        ImageView defaultIcon = (ImageView) convertView.findViewById(R.id.defaultIcon);
        defaultIcon.setBackgroundResource(R.drawable.list_data_model);

        TextView defaultDescription = (TextView) convertView.findViewById(R.id.defaultDescription);
        defaultDescription.setText(bcData.companyName);

        if (position % 2 == 0)
        {
            convertView.setBackgroundColor(Color.parseColor("#FFFFFFFF"));
            defaultDescription.setTextColor(Color.parseColor("#FF303F9F"));
        }
        else
        {
            convertView.setBackgroundColor(Color.parseColor("#FF0099cc"));
            defaultDescription.setTextColor(Color.parseColor("#FFFFFFFF"));
        }
        return convertView;
    }
}
