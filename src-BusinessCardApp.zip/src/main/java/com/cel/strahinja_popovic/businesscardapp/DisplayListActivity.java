package com.cel.strahinja_popovic.businesscardapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

/**
 * Student name: Strahinja Popovic
 * University of Canberra Student ID: u3165021
 * Subject: Mobile Technologies
 * Purpose: Business Card App Scanner
 */

public class DisplayListActivity extends AppCompatActivity
{
    ArrayList<BusinessCardData> arrayData = new ArrayList<BusinessCardData>();
    BusinessCardSQLiteDb SQLiteDb = new BusinessCardSQLiteDb(this, "Business_Card Database", null, 16);

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_list);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        arrayData = SQLiteDb.getAllData();
        if (arrayData.isEmpty())
        {
            SQLiteDb.insertCardData(new BusinessCardData("Big Data", "John Smith", "Executive Manager", "444 555 888", "msmith@domain.com", R.drawable.list_data_model));
            SQLiteDb.insertCardData(new BusinessCardData("Web Software", "Larry Bird", "Software Developer", "333 444 555", "lbird@domain.com", R.drawable.list_data_model));
            SQLiteDb.insertCardData(new BusinessCardData("Mobile Apps", "John Doe","Database Administrator", "555 888 222", "jdoe@domain.com", R.drawable.list_data_model));
            arrayData = SQLiteDb.getAllData();
        }
        final ListView listItem = (ListView) findViewById(R.id.displayListView);
        BusinessCardDataAdapter adapter = new BusinessCardDataAdapter(this, R.layout.list_view_layout, arrayData);
        listItem.setAdapter(adapter);

        listItem.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                BusinessCardData businessCardData = arrayData.get(position);
                Intent intent = new Intent(view.getContext(), DataEventActivity.class);
                intent.putExtra("companyName", businessCardData.companyName);
                intent.putExtra("fullName", businessCardData.fullName);
                intent.putExtra("jobTitle", businessCardData.jobTitle);
                intent.putExtra("phoneNumber", businessCardData.phoneNumber);
                intent.putExtra("emailAddress", businessCardData.emailAddress);
                intent.putExtra("imageResource", businessCardData.imageResource);
                startActivity(intent);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_display_list, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.menu_item_first)
        {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
    public void addImagePage(View view)
    {
        Intent intent = new Intent(this, CognitiveServiceActivity.class);
        startActivity(intent);
    }
    public void goToHome(View view)
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
class BusinessCardData
{
    String companyName;
    String fullName;
    String jobTitle;
    String phoneNumber;
    String emailAddress;
    int imageResource;

    public BusinessCardData(
            String companyName,
            String fullName,
            String jobTitle,
            String phoneNumber,
            String emailAddress,
            int imageResource)
    {
        this.companyName = companyName;
        this.fullName = fullName;
        this.jobTitle = jobTitle;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.imageResource = imageResource;
    }
    @Override
    public String toString()
    {
        return this.companyName;
    }
}
