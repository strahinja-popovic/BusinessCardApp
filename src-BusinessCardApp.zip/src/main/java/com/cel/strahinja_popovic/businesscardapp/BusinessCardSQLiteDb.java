package com.cel.strahinja_popovic.businesscardapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

/**
 * Student name: Strahinja Popovic
 * University of Canberra Student ID: u3165021
 * Subject: Mobile Technologies
 * Purpose: Business Card App Scanner
 */

public class BusinessCardSQLiteDb extends SQLiteOpenHelper
{
    public static final String ID = "id";
    public static final String CARD_DATA = "card_data";
    public static final String COMPANY_NAME = "CompanyName";
    public static final String FULL_NAME = "FullName";
    public static final String JOB_TITLE = "JobTitle";
    public static final String PHONE_NUMBER = "PhoneNumber";
    public static final String EMAIL_ADDRESS = "EmailAddress";
    public static final String IMAGE_RESOURCE = "ImageResource";

    public BusinessCardSQLiteDb(Context context, String name, SQLiteDatabase.CursorFactory factory, int version)
    {
        super(context, name, factory, version);
    }
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("create table " + CARD_DATA + "(" +
                ID + " integer primary key, " +
                COMPANY_NAME + " text not null default 'n/a', " +
                FULL_NAME + " text not null default 'n/a', " +
                JOB_TITLE + " text not null default 'n/a', " +
                PHONE_NUMBER + " text not null default 'n/a', " +
                EMAIL_ADDRESS + " text not null default 'n/a', " +
                IMAGE_RESOURCE + " integer not null default '999');");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("drop table if exists " + CARD_DATA);
        onCreate(db);
    }
    public String getBusinessCardID(String company, String name, String title, String phone, String email)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor result = db.rawQuery("" +
                "select " + ID +
                " from " + CARD_DATA +
                " where " + COMPANY_NAME + " = '" + company + "'" +
                " and " + FULL_NAME + " = '" + name + "'" +
                " and " + JOB_TITLE + " = '" + title + "'" +
                " and " + PHONE_NUMBER + " = '" + phone + "'" +
                " and " + EMAIL_ADDRESS + " = '" + email + "'", null);
        String businessCardID = "";
        if(result.moveToFirst())
        {
            businessCardID = result.getString(result.getColumnIndex(ID));
        }
        return businessCardID;
    }
    public String getBusinessCardIDTest(String company, String name)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor result = db.rawQuery("" +
                "select " + ID +
                " from " + CARD_DATA +
                " where " + COMPANY_NAME + " = '" + company + "'" +
                " and " + FULL_NAME + " = '" + name + "'", null);
        String businessCardID = "";
        if(result.moveToFirst())
        {
            businessCardID = result.getString(result.getColumnIndex(ID));
        }
        return businessCardID;
    }
    public void updateBusinessCardDatabase(String id, String company, String name, String title, String phone, String email)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COMPANY_NAME, company);
        contentValues.put(FULL_NAME, name);
        contentValues.put(JOB_TITLE, title);
        contentValues.put(PHONE_NUMBER, phone);
        contentValues.put(EMAIL_ADDRESS, email);
        db.update(CARD_DATA, contentValues, "id = ? ", new String[]{id});
    }
    public ArrayList<BusinessCardData> getAllData()
    {
        ArrayList<BusinessCardData> dataList = new ArrayList<BusinessCardData>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor result = db.rawQuery("select * from " + CARD_DATA, null);
        result.moveToFirst();

        while (result.isAfterLast() == false)
        {
            BusinessCardData bcData = new BusinessCardData(
                    result.getString(result.getColumnIndex(COMPANY_NAME)),
                    result.getString(result.getColumnIndex(FULL_NAME)),
                    result.getString(result.getColumnIndex(JOB_TITLE)),
                    result.getString(result.getColumnIndex(PHONE_NUMBER)),
                    result.getString(result.getColumnIndex(EMAIL_ADDRESS)),
                    result.getInt(result.getColumnIndex(IMAGE_RESOURCE)));
            dataList.add(bcData);
            result.moveToNext();
        }
        return dataList;
    }
    public boolean insertCardData(BusinessCardData data)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COMPANY_NAME, data.companyName);
        contentValues.put(FULL_NAME, data.fullName);
        contentValues.put(JOB_TITLE, data.jobTitle);
        contentValues.put(PHONE_NUMBER, data.phoneNumber);
        contentValues.put(EMAIL_ADDRESS, data.emailAddress);
        contentValues.put(IMAGE_RESOURCE, data.imageResource);
        db.insert(CARD_DATA, null, contentValues);
        return true;
    }
    public Integer deleteCardData(String id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(CARD_DATA, "id = ? ", new String[]{id});
    }
    public boolean updateCardData(String id, BusinessCardData data)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COMPANY_NAME, data.companyName);
        contentValues.put(FULL_NAME, data.fullName);
        contentValues.put(JOB_TITLE, data.jobTitle);
        contentValues.put(PHONE_NUMBER, data.phoneNumber);
        contentValues.put(EMAIL_ADDRESS, data.emailAddress);
        contentValues.put(IMAGE_RESOURCE, data.imageResource);
        db.update(CARD_DATA, contentValues, "id = '" + id + "'", new String[]{id});
        return true;
    }
}
