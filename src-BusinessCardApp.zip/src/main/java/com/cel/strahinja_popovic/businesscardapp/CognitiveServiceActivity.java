package com.cel.strahinja_popovic.businesscardapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.gson.Gson;
import com.microsoft.projectoxford.vision.VisionServiceClient;
import com.microsoft.projectoxford.vision.VisionServiceRestClient;
import com.microsoft.projectoxford.vision.contract.LanguageCodes;
import com.microsoft.projectoxford.vision.contract.Line;
import com.microsoft.projectoxford.vision.contract.OCR;
import com.microsoft.projectoxford.vision.contract.Region;
import com.microsoft.projectoxford.vision.contract.Word;
import com.microsoft.projectoxford.vision.rest.VisionServiceException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * Student name: Strahinja Popovic
 * University of Canberra Student ID: u3165021
 * Subject: Mobile Technologies
 * Purpose: Business Card App Scanner
 */

public class CognitiveServiceActivity extends AppCompatActivity
{
    private TextView txtRenderData;

    private Uri mImageUri;
    private Bitmap mBitmap;

    private VisionServiceClient client;

    private static final int REQUEST_TAKE_PHOTO = 0;
    private static final int REQUEST_SELECT_IMAGE_IN_ALBUM = 1;

    BusinessCardSQLiteDb SQLiteDb = new BusinessCardSQLiteDb(this, "Business_Card Database", null, 16);

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cognitive_service);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        txtRenderData = (TextView) findViewById(R.id.txtCognitiveServiceDescription);

        if (client==null)
        {
            client = new VisionServiceRestClient("4b4403aee66248cd89525e63304c69ea",
                    "https://australiaeast.api.cognitive.microsoft.com/vision/v1.0");
        }
    }
    public void captureImage(View view)
    {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null)
        {
            startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);
        }
    }
    public void uploadImage(View view)
    {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        if (intent.resolveActivity(getPackageManager()) != null)
        {
            startActivityForResult(intent, REQUEST_SELECT_IMAGE_IN_ALBUM);
        }
    }
    public void runOCR()
    {
        try
        {
            new doRequest().execute();
        }
        catch (Exception e)
        {
            txtRenderData.setText("Error encountered. Exception is: " + e.toString());
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (requestCode == REQUEST_TAKE_PHOTO && resultCode == RESULT_OK)
        {
            Bundle extras = data.getExtras();
            mBitmap = (Bitmap) extras.get("data");
            txtRenderData.setText("Loading...");
            if (mBitmap != null)
            {
                ImageView previewImageCapture = (ImageView) findViewById(R.id.previewImageCapture);
                previewImageCapture.setImageBitmap(mBitmap);
                runOCR();
            }
        }
        if (requestCode == REQUEST_SELECT_IMAGE_IN_ALBUM && resultCode == RESULT_OK)
        {
            // If image is selected successfully, set the image URI and bitmap.
            mImageUri = data.getData();
            mBitmap = CognitiveServiceImageHelper.loadSizeLimitedBitmapFromUri(mImageUri, getContentResolver());
            if (mBitmap != null)
            {
                ImageView previewImageUpload = (ImageView) findViewById(R.id.previewImageUpload);
                previewImageUpload.setImageBitmap(mBitmap);
                runOCR();
            }
        }
    }
    private class doRequest extends AsyncTask<String, String, String>
    {
        // Store error message
        private Exception e = null;

        public doRequest()
        {

        }
        @Override
        protected String doInBackground(String... args)
        {
            try
            {
                return process();
            }
            catch (Exception e)
            {
                this.e = e;    // Store error
            }
            return null;
        }
        @Override
        protected void onPostExecute(String data)
        {
            super.onPostExecute(data);
            // Display based on error existence
            if (e != null)
            {
                txtRenderData.setText("Error: " + e.getMessage());
                this.e = null;
            }
            else
            {
                Gson gson = new Gson();
                OCR r = gson.fromJson(data, OCR.class);
                String result = "";
                for (Region reg : r.regions)
                {
                    for (Line line : reg.lines)
                    {
                        for (Word word : line.words)
                        {
                            result += word.text + " ";
                        }
                        result += "\n";
                    }
                }

                txtRenderData.setText(result);

                int start_0 = txtRenderData.getLayout().getLineStart(0);
                int end_0 = txtRenderData.getLayout().getLineEnd(0);

                int start_1 = txtRenderData.getLayout().getLineStart(1);
                int end_1 = txtRenderData.getLayout().getLineEnd(1);

                int start_2 = txtRenderData.getLayout().getLineStart(2);
                int end_2 = txtRenderData.getLayout().getLineEnd(2);

                int start_3 = txtRenderData.getLayout().getLineStart(3);
                int end_3 = txtRenderData.getLayout().getLineEnd(3);

                int start_4 = txtRenderData.getLayout().getLineStart(4);
                int end_4 = txtRenderData.getLayout().getLineEnd(4);

                String line_0 = txtRenderData.getText().toString().substring(start_0, end_0);
                String line_1 = txtRenderData.getText().toString().substring(start_1, end_1);
                String line_2 = txtRenderData.getText().toString().substring(start_2, end_2);
                String line_3 = txtRenderData.getText().toString().substring(start_3, end_3);
                String line_4 = txtRenderData.getText().toString().substring(start_4, end_4);

                if(line_0.equalsIgnoreCase("") || line_0 == null)
                {
                    line_0 = "n/a";
                }
                if(line_1.equalsIgnoreCase("") || line_1 == null)
                {
                    line_1 = "n/a";
                }
                if(line_2.equalsIgnoreCase("") || line_2 == null)
                {
                    line_2 = "n/a";
                }
                if(line_3.equalsIgnoreCase("") || line_3 == null)
                {
                    line_3 = "n/a";
                }
                if(line_4.equalsIgnoreCase("") || line_4 == null)
                {
                    line_4 = "n/a";
                }

                SQLiteDb.insertCardData(new BusinessCardData(
                        line_0.replace("\n", "").replace("\"", "").replace("\'", ""),
                        line_1.replace("\n", "").replace("\"", "").replace("\'", ""),
                        line_2.replace("\n", "").replace("\"", "").replace("\'", ""),
                        line_3.replace("\n", "").replace("\"", "").replace("\'", ""),
                        line_4.replace("\n", "").replace("\"", "").replace("\'", ""),
                        R.drawable.list_data_model));

                final String _line_0 = line_0;
                final String _line_1 = line_1;
                final String _line_2 = line_2;
                final String _line_3 = line_3;
                final String _line_4 = line_4;

                txtRenderData.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        /*
                        int lineCount = txtRenderData.getLineCount();
                        txtRenderData.setText("" + lineCount);
                        */

                        txtRenderData.setText(
                                  "" + _line_0.replace("\n", "") +
                                "\n" + _line_1.replace("\n", "")+
                                "\n" + _line_2.replace("\n", "")+
                                "\n" + _line_3.replace("\n", "") +
                                "\n" + _line_4.replace("\n", ""));
                        txtRenderData.setTextSize(18);
                        txtRenderData.setTextColor(Color.parseColor("#FF303F9F"));
                        txtRenderData.setBackgroundColor(Color.parseColor("#FFFFFFFF"));
                    }
                });
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_cognitive_service, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();

        if (id == R.id.menu_item_first)
        {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        else if(id == R.id.menu_item_last)
        {
            Intent intent = new Intent(this, DisplayListActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
    public void displyListViewData(View view)
    {
        Intent intent = new Intent(this, DisplayListActivity.class);
        startActivity(intent);
    }
    private String process() throws VisionServiceException, IOException
    {
        Gson gson = new Gson();

        ByteArrayOutputStream output = new ByteArrayOutputStream();
        mBitmap.compress(Bitmap.CompressFormat.JPEG, 100, output);
        ByteArrayInputStream inputStream = new ByteArrayInputStream(output.toByteArray());

        OCR ocr;
        ocr = this.client.recognizeText(inputStream, LanguageCodes.AutoDetect, true);

        String result = gson.toJson(ocr);
        Log.d("result", result);

        return result;
    }
}
