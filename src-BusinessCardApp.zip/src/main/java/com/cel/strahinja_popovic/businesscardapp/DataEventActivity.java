package com.cel.strahinja_popovic.businesscardapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Student name: Strahinja Popovic
 * University of Canberra Student ID: u3165021
 * Subject: Mobile Technologies
 * Purpose: Business Card App Scanner
 */

public class DataEventActivity extends AppCompatActivity
{
    BusinessCardSQLiteDb SQLiteDb = new BusinessCardSQLiteDb(this, "Business_Card Database", null, 16);

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_event);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Bundle extras = getIntent().getExtras();
        final String companyName = extras.getString("companyName");
        final String fullName = extras.getString("fullName");
        final String jobTitle = extras.getString("jobTitle");
        final String phoneNumber = extras.getString("phoneNumber");
        final String emailAddress = extras.getString("emailAddress");
        final int imageResource = extras.getInt("imageResource");

        TextView txtDataCompanyName = (TextView) findViewById(R.id.txtCompanyName);
        txtDataCompanyName.setText(companyName);

        TextView txtDataFullName = (TextView) findViewById(R.id.txtFullName);
        txtDataFullName.setText(fullName);

        TextView txtDataJobTitle = (TextView) findViewById(R.id.txtJobTitle);
        txtDataJobTitle.setText(jobTitle);

        TextView txtDataPhoneNumber = (TextView) findViewById(R.id.txtPhoneNumber);
        txtDataPhoneNumber.setText(phoneNumber);

        TextView txtDataEmailAddress = (TextView) findViewById(R.id.txtEmailAddress);
        txtDataEmailAddress.setText(emailAddress);

        Button btnEdit = (Button) findViewById(R.id.btnEdit);
        btnEdit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(view.getContext(), EditDataActivity.class);
                intent.putExtra("companyName", companyName);
                intent.putExtra("fullName", fullName);
                intent.putExtra("jobTitle", jobTitle);
                intent.putExtra("phoneNumber", phoneNumber);
                intent.putExtra("emailAddress", emailAddress);
                startActivity(intent);
            }
        });
        Button btnDelete = (Button) findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                String id = SQLiteDb.getBusinessCardID(companyName, fullName, jobTitle, phoneNumber, emailAddress);
                String id_test = SQLiteDb.getBusinessCardIDTest(companyName, fullName);
                SQLiteDb.deleteCardData(id);

                Intent intent = new Intent(DataEventActivity.this, DisplayListActivity.class);
                startActivity(intent);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_data_event, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.menu_item_first)
        {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        else if(id == R.id.menu_item_last)
        {
            Intent intent = new Intent(this, DisplayListActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}
