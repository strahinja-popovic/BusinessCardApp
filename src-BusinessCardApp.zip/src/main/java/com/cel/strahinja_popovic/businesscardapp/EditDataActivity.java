package com.cel.strahinja_popovic.businesscardapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.method.KeyListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class EditDataActivity extends AppCompatActivity
{
    BusinessCardSQLiteDb SQLiteDb = new BusinessCardSQLiteDb(this, "Business_Card Database", null, 16);

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_data);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Bundle extras = getIntent().getExtras();
        final String companyName = extras.getString("companyName");
        final String fullName = extras.getString("fullName");
        final String jobTitle = extras.getString("jobTitle");
        final String phoneNumber = extras.getString("phoneNumber");
        final String emailAddress = extras.getString("emailAddress");

        final String id = SQLiteDb.getBusinessCardID(companyName, fullName, jobTitle, phoneNumber, emailAddress);

        EditText txtID = (EditText) findViewById(R.id.txtID);
        txtID.setText("Database ID: " + id);
        KeyListener keyListener = txtID.getKeyListener();
        txtID.setKeyListener(null);

        final EditText txtCompanyName = (EditText) findViewById(R.id.txtCompanyName);
        txtCompanyName.setText(companyName);

        final EditText txtFullName = (EditText) findViewById(R.id.txtFullName);
        txtFullName.setText(fullName);

        final EditText txtJobTitle = (EditText) findViewById(R.id.txtJobTitle);
        txtJobTitle.setText(jobTitle);

        final EditText txtPhoneNumber = (EditText) findViewById(R.id.txtPhoneNumber);
        txtPhoneNumber.setText(phoneNumber);

        final EditText txtEmailAddress = (EditText) findViewById(R.id.txtEmailAddress);
        txtEmailAddress.setText(emailAddress);

        Button btnEditData = (Button) findViewById(R.id.btnEditData);
        btnEditData.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                String company = txtCompanyName.getText().toString();
                String name = txtFullName.getText().toString();
                String title = txtJobTitle.getText().toString();
                String phone = txtPhoneNumber.getText().toString();
                String email = txtEmailAddress.getText().toString();

                SQLiteDb.updateBusinessCardDatabase(
                        id.replace("\n", "").replace("\"", "").replace("\'", ""),
                        company.replace("\n", "").replace("\"", "").replace("\'", ""),
                        name.replace("\n", "").replace("\"", "").replace("\'", ""),
                        title.replace("\n", "").replace("\"", "").replace("\'", ""),
                        phone.replace("\n", "").replace("\"", "").replace("\'", ""),
                        email.replace("\n", "").replace("\"", "").replace("\'", ""));

                Intent intent = new Intent(view.getContext(), DisplayListActivity.class);

                intent.putExtra("companyName", company);
                intent.putExtra("fullName", name);
                intent.putExtra("jobTitle", title);
                intent.putExtra("phoneNumber", phone);
                intent.putExtra("emailAddress", email);
                intent.putExtra("imageResource", R.drawable.list_data_model);

                startActivity(intent);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_edit_data, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.menu_item_first)
        {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        else if(id == R.id.menu_item_last)
        {
            Intent intent = new Intent(this, DisplayListActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
    public void displayListActivity(View view)
    {
        Intent intent = new Intent(this, DisplayListActivity.class);
        startActivity(intent);
    }
}
